package com.cts.pss.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.pss.entity.Product;

@RestController
public class PriceController {

	@GetMapping("/api/price/{id}")
	public Product getPrice(@PathVariable int id) {
		
		Map<String, Integer> uriVariables=new HashMap<>();  
		uriVariables.put("id", id);		
		ResponseEntity<Product>responseEntity=new RestTemplate().getForEntity("http://localhost:8081/api/products/getPrice/{id}", Product.class, uriVariables);  
		Product response=responseEntity.getBody();  
		return new Product(id,response.getPrice());
	}
}
