package com.cts.pss.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.pss.entity.Order;

public interface OrderDao extends JpaRepository<Order, Integer> {

	@Query("from Order o where o.userName = ?1")
	List<Order> findByUser(String user);
}
