package com.cts.pss.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


import com.cts.pss.dao.OrderDao;

import com.cts.pss.entity.Order;
import com.cts.pss.entity.Cart;
import com.cts.pss.entity.Item;

@RestController

public class OrderController {

	@Autowired
	private OrderDao orderRepository;

	@GetMapping("/api/orders/{user}")
	public List<Order> save(@PathVariable String user) {

		String url = "http://localhost:8083/api/cart/" + user;
		System.out.println("Fetching cart data from " + url);

		RestTemplate restTemplate = new RestTemplate(); // Micro Service inter Communication

		ResponseEntity<Cart[]> response = restTemplate.getForEntity(url, Cart[].class);

		Cart[] cartItems = response.getBody();
		String pattern = "yyyy-MM-dd HH:mm:ss SSS";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(pattern);
		Order orders = null;
		
		for(Cart cart : cartItems) {
			LocalDateTime now = LocalDateTime.now();
			String orderDate = dtf.format(now).toString();
			
			double totalAmt = cart.getItem().getPrice() * cart.getQuantity();
			orders = new Order(orderDate, totalAmt, cart.getUsername());
			orderRepository.save(orders);
		}
		restTemplate.delete(url);
		List<Order> ordersList = orderRepository.findAll();

		return ordersList;
	}

	@GetMapping("/api/orders/view/{user}")
	public List<Order> viewOrders(@PathVariable String user){
		List<Order> ordersList = orderRepository.findByUser(user);

		return ordersList;
	}
}