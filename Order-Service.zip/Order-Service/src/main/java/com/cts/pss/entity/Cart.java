package com.cts.pss.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

public class Cart {
	
	private String username;
	private Item item;
	
	private int quantity;

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cart(String username, Item item, int quantity) {
		super();
		this.username = username;
		this.item = item;
		this.quantity = quantity;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}