package com.cts.pss.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.pss.entity.Product;

public interface ProductDao extends JpaRepository<Product, Integer>{

	List<Product> findById(int id);
	List<Product> findAll();
	
	@Query(value = "from Product p where p.name like %:ch%")
	List<Product> findByContainsLetter(@Param("ch") char c);
	
}
