package com.cts.pss.controller;

import java.util.List;
import org.springframework.http.HttpStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cts.pss.dao.ProductDao;
import com.cts.pss.dao.ReviewDao;
import com.cts.pss.entity.Product;
import com.cts.pss.entity.Review;

@RestController
public class ReviewController {

	@Autowired
	ReviewDao revDao;
	@Autowired
	ProductDao product;
	
	@GetMapping("/api/products/{id}/reviews")
	public List<Review> findById(@PathVariable int id){
		
		List<Review> reviews = revDao.findByProductId(id);
		
		return reviews;
	}
	
	@PostMapping("/api/products/{id}/reviews")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Review> createProduct(@RequestBody Review review, @PathVariable int id){
		
		List<Product> prod = product.findById(id);
		for(Product p1 : prod) {
		Review reviews = new Review();
		reviews.setStars(review.getStars());
		reviews.setAuthor(review.getAuthor());
		reviews.setBody(review.getBody());
		reviews.setProduct(p1);
		revDao.save(reviews);
		}
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
}
