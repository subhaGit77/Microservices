package com.cts.pss.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cts.pss.dao.ProductDao;
import com.cts.pss.entity.Product;

@RestController
public class ProductController {

	
	@Autowired
	  private ProductDao prodDao;
	
	@GetMapping("/api/products/{id}")
	  public List<Product> retrieveProductsById
	    (@PathVariable int id){
	    
	    List<Product> products = 
	    		prodDao.findById(id);
	    
	    
	    return products;
	  }
	
	@GetMapping("/api/products/byName/{ch}")
	  public List<Product> retrieveProductsHasChar
	    (@PathVariable char ch){
	    
	    List<Product> products = 
	    		prodDao.findByContainsLetter(ch);
	    
	    
	    return products;
	  }
	
	@GetMapping("/api/products")
	  public List<Product> retrieveAllProducts(){
	    
	    List<Product> products = 
	    		prodDao.findAll();
	    
	    
	    return products;
	  }
	
	@PostMapping("/api/products/")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Product> createProduct(@RequestBody Product products){
		Product prod = new Product();
		prod.setName(products.getName());
		prod.setDescription(products.getDescription());
		prod.setPrice(products.getPrice());
		return new ResponseEntity<>(prodDao.save(prod),HttpStatus.CREATED);
	} 
	
	@PostMapping("/api/products/all/")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Product> createNProducts(@RequestBody List<Product> products){
		
		for (Product p1 : products) {
			Product prod = new Product();
			prod.setName(p1.getName());
			prod.setDescription(p1.getDescription());
			prod.setPrice(p1.getPrice());
			prodDao.save(prod);
		}
		
		return new ResponseEntity<Product>(HttpStatus.CREATED);
	} 
}
