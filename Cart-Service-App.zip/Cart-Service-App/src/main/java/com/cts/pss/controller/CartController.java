package com.cts.pss.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.pss.entity.Cart;
import com.cts.pss.entity.Item;
import com.cts.pss.entity.dao.CartDao;
import com.cts.pss.entity.dao.ItemDao;

@RestController
public class CartController {

	@Autowired CartDao cartRepository;
	@Autowired ItemDao itemRepo;
	
	@PostMapping("/api/cart/{user}")
	@ResponseBody
	public ResponseEntity<Cart> addToCart(@PathVariable String user, @RequestBody Cart cart){
		int productId = cart.getItem().getId();
		String productURL = "http://localhost:8081/api/products/"+productId;
		ResponseEntity<Item> responseEntity = new RestTemplate().getForEntity(productURL, Item.class);  
		Item item = responseEntity.getBody();
		double itemTotal = (double) item.getPrice()*cart.getQuantity();
		item.setItemTotal(itemTotal);
		itemRepo.save(item);
		
		cart.setItem(item);
		cart.setUsername(user);
		cartRepository.save(cart);
		return ResponseEntity.ok(cart);
				
		
	}
	
	@GetMapping("/api/cart/{user}")
	public List<Cart> getCartItems(@PathVariable String user){
		
		List<Cart> cartItems = cartRepository.findByName(user);
		
		return cartItems;
	}
	
	@DeleteMapping("/api/cart/{user}")
	public Map<String, Boolean> removeItems(@PathVariable String user) {
		
		List<Cart> cart = cartRepository.findByName(user);
		
		cartRepository.deleteAll(cart);
		
		Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
	}
}
