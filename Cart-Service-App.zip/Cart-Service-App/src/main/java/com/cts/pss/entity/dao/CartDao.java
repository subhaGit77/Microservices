package com.cts.pss.entity.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.pss.entity.Cart;

public interface CartDao extends JpaRepository<Cart, String>{

	@Query("from Cart c where c.username = ?1")
	List<Cart> findByName(String username);
	
	
}
