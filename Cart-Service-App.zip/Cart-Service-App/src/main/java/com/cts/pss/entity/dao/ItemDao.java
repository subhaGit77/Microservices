package com.cts.pss.entity.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.pss.entity.Item;

public interface ItemDao extends JpaRepository<Item, Integer>{

}
