package com.cts.pss.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "item_details")
public class Item {

	@Id
	@GeneratedValue
	private int itemId;
	
	private int id;
	private String name;
	private String description;
	private double price;
	private double itemTotal;
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Item(int productId, String name, String description, double price, double itemTotal) {
		super();
		this.id = productId;
		this.name = name;
		this.description = description;
		this.price = price;
		this.itemTotal = itemTotal;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getItemTotal() {
		return itemTotal;
	}
	public void setItemTotal(double itemTotal) {
		this.itemTotal = itemTotal;
	}
	
	
}
